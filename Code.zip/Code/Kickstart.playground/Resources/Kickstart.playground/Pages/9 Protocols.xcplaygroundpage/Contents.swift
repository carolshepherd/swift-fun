//: ## Protocols
//: [TOC](TOC) - [Previous](@previous) - [Next](@next)
let vertex = Vertex(x: 3, y: 4)
let movedRightBy10Vertex = vertex.movedByX(10)

vertex == movedRightBy10Vertex
vertex != movedRightBy10Vertex

let rectangle = Rectangle(topLeftCorner: vertex, width: 100, height: 50)
let movedLeftBy7Rectangle = rectangle.movedByX(-7)

let shiftedLeftVertex = shiftLeft(vertex)
let shiftedLeftRectangle = shiftLeft(rectangle)

let returnedVertex = shiftedLeftVertex.shiftRight()
let returnedRectangle = shiftedLeftRectangle.shiftRight()

returnedVertex == vertex
returnedRectangle == rectangle

let movableRectangle: Movable = rectangle
let shiftRightRectangle = rectangle.shiftRight()
let shiftRightMovableRectangle = movableRectangle.shiftRight()

//: [TOC](TOC) - [Previous](@previous) - [Next](@next)
