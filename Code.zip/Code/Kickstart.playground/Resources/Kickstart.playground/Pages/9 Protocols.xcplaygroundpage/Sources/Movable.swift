public protocol Movable {
    func movedByX(deltaX: Int) -> Self
    func shiftRight() -> Self
}

public func shiftLeft<T: Movable>(movable: T) -> T {
    return movable.movedByX(-1)
}

public extension Movable {
    public func shiftRight() -> Self {
        return self.movedByX(1)
    }
}