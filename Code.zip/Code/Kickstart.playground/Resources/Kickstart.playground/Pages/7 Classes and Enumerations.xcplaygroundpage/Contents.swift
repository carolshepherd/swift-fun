//: ## Classes and Enumerations
//: [TOC](TOC) - [Previous](@previous) - [Next](@next)

class Student {
    let name: String
    let hometown: String?
    private(set) var registration = Registration.regular

    
    init(name: String, hometown: String? = nil) {
        self.name = name
        self.hometown = hometown
    }
    func nameBadge() -> String {
        let location = hometown ?? "here and there"
        return "Hello, I'm \(name) from \(location)."
    }
}

class CurrentStudent: Student {
    
    init(name: String, tutorial: Tutorial, hometown: String? = nil) {
        super.init(name: name, hometown: hometown)
        registration = .full(tutorial)
    }
    override func nameBadge() -> String {
        let tutorialName =  registration.tutorial?.name ?? "no tutorial"
        return super.nameBadge() + " I'm taking \(tutorialName)."
    }
}

let daniel = Student(name: "Daniel", hometown: "Shaker Heights")
daniel.nameBadge()

let kimberli = CurrentStudent(name: "Kimberli", tutorial: .swift)
kimberli.nameBadge()

//: [TOC](TOC) - [Previous](@previous) - [Next](@next)
