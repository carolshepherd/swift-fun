//: ## Enumerations
//: [TOC](TOC) - [Previous](@previous) - [Next](@next)
enum Tutorial: String {
    case lldb = "Debugging in Swift"
    case iOS9
    case swift = "A Swift Kickstart"
    case coredata
    
    var name: String {
        return rawValue
    }
}

var tutorial = Tutorial.iOS9
tutorial = .swift
tutorial.name

enum Registration {
    case regular
    case full(Tutorial)
    
    var tutorial: Tutorial? {
        switch self {
        case .full(let course):
            return course
        default:
            return nil
        }
    }
}

let registration = Registration.full(tutorial)
registration.tutorial





//: [TOC](TOC) - [Previous](@previous) - [Next](@next)
