//: ## Classes
//: [TOC](TOC) - [Previous](@previous) - [Next](@next)

class Student {
    let name: String
    let hometown: String?
    
    init(name: String, hometown: String? = nil) {
        self.name = name
        self.hometown = hometown
    }
    func nameBadge() -> String {
        let location = hometown ?? "here and there"
        return "Hello, I'm \(name) from \(location)."
    }
}

class CurrentStudent: Student {
    let tutorial: String
    
    init(name: String, tutorial: String, hometown: String? = nil) {
        self.tutorial = tutorial
        super.init(name: name, hometown: hometown)
    }
    override func nameBadge() -> String {
        return super.nameBadge() + " I'm taking \(tutorial)."
    }
}

let daniel = Student(name: "Daniel", hometown: "Shaker Heights")
daniel.nameBadge()

let kimberli = CurrentStudent(name: "Kimberli", tutorial: "Swift")
kimberli.nameBadge()

//: [TOC](TOC) - [Previous](@previous) - [Next](@next)
