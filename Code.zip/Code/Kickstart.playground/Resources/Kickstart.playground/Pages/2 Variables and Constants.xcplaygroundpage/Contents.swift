//: ## Variables and Constants
//: [TOC](TOC) - [Previous](@previous) - [Next](@next)

/*
let literalCalculation = 5 * 6.0

let someInt = 6

let someDouble = 5.0

// let productAsDouble = someInt * someDouble

let someIntAsDouble = Double(someInt)

let productAsDouble = someIntAsDouble * someDouble*/

let person = "Class Attendee"

func welcomeToColumbus(name: String) -> String {
    let greeting = "\(name), welcome to Columbus."
    return greeting
}
func welcomeToBoston(name: String) -> String {
    let greeting = "\(name), welcome to Boston."
    return greeting
}

let greeting1 = welcomeToColumbus(person)
let greeting2 = welcomeToBoston(person)

func welcomeToColumbus() -> String {
    return "Welcome to Columbus"
}

let columbusWelcome = welcomeToColumbus(_:)
let shortColumbusWelcome = welcomeToColumbus()


let greeting3 = columbusWelcome(person)

func traditionalWelcome(to name: String,
                        from location: String)
    -> String {
        let greeting = "\(name), welcome to \(location)."
        return greeting
}

let greeting4 = traditionalWelcome(to: "Joe", from: "Amsterdam")

func welcomeToLocation(location: String) -> (String) -> String {
    func locationWelcome(name: String) -> String {
        let greeting = "\(name), welcome to \(location)."
        return greeting
    }
    return locationWelcome
}

let cbusWelcome = welcomeToLocation("Columbus")
let greeting5 = cbusWelcome(person)

let greeting6 = welcomeToLocation("Boston")(person)

func welcome(name: String,
             withMessage message:(String) -> String) -> String {
    return message(name)
}

let greeting7 = welcome(person, withMessage: cbusWelcome)


//: [TOC](TOC) - [Previous](@previous) - [Next](@next)
