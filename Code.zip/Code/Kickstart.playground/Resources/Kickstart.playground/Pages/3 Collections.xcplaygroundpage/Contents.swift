//: ## Collections
//: [TOC](TOC) - [Previous](@previous) - [Next](@next)

import Foundation

let badNumbers = [0, 1, 2, "Iguana"]

let badOne = (badNumbers[1] as! NSNumber).integerValue
let badTwo = (badNumbers[2] as! NSNumber).integerValue

let badThree = badOne + badTwo


let numbers = [0,1,2]

var evens = [0,2,4]
evens.append(6)
evens[1] = 8
evens.insert(10, atIndex: 2)
evens[1...2] = [12,14,16]
evens += [100]
evens[0...0] = [200, 202, 204]

//evens.removeLast()
//evens.removeAtIndex(2)
//evens.removeRange(1 ... 4)
//evens.removeAll(keepCapacity: true)

let sortedEvens = evens.sort()
evens.sortInPlace()


evens

for i in 0 ..< evens.count {
    // do something
}

for even in evens {
    // do something
}

evens.forEach{ $0 /* do something with $0 representing the element */ }

for (index, even) in evens.enumerate() {
    // do something
}

var digits = ["one": 1, "two": 2, "three": 3]

digits["two"]
digits["four"] = 5
digits["five"] = 5
digits.removeValueForKey("five")
digits.removeValueForKey("not here")
digits["four"] = 4

digits

let theKeys = digits.keys

for key in theKeys {
    print("\(digits[key])")
}

if digits["two"] != nil {
    let digit = digits["two"]!
    print("\(digit)")
} else {
    print("no entry matches key")
}

if let digit = digits["two"] {
    print("\(digit)")
} else {
    print("no entry matches key")
}

var evenSet = Set(evens)
var primeSet: Set = [2, 3, 5, 7, 9]
evenSet.remove(200)

for i in 0.stride(through: 10, by: 2) {
    evenSet.insert(i)
}

let intersection = evenSet.intersect(primeSet)
let union = evenSet.union(primeSet).sort()
let difference = evenSet.subtract(primeSet).sort()
let symmetricDifference = evenSet.exclusiveOr(primeSet).sort()
intersection.isDisjointWith(symmetricDifference)
intersection.isSubsetOf(union)


//: [TOC](TOC) - [Previous](@previous) - [Next](@next)