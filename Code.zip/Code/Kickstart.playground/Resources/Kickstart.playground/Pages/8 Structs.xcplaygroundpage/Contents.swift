//: ## Structs
//: [TOC](TOC) - [Previous](@previous) - [Next](@next)

struct Student {
    var name: String {
        willSet {
            print("Name will change from \(name) to \(newValue).")
        }
        didSet {
            if name != "Fred" {
                print("Name did change from \(oldValue) to \(name).")
            } else {
                name = oldValue
                print("Name will remain \(name).")
            }
        }
    }
    let hometown: String
    
    mutating func rename(name: String) {
        self.name = name
    }
    
    func relocated(hometown: String) -> Student {
        return Student(name: name, hometown: hometown)
    }
}

var daniel = Student(name: "Daniel", hometown: "Shaker Heights")
var kimberli = daniel
kimberli.name = "Kimberli"
kimberli.name
daniel.name = "Fred"

daniel.rename("Danny")
daniel.name

let movedDaniel = daniel.relocated("London")
movedDaniel.hometown
daniel.hometown



//: [TOC](TOC) - [Previous](@previous) - [Next](@next)