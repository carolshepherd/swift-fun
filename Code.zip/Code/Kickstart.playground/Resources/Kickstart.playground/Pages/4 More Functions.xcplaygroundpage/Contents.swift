//: ## More Functions
//: [TOC](TOC) - [Previous](@previous) - [Next](@next)


/*
 extension Int {
 func doubled() -> Int {
 return self * 2
 }
 }
 */

var number = 6
var doubleNumber = 5.0
var string = "my String"


/*func doubled(input: Int) -> Int {
    return input * 2
}*/

func modify<T>(input: T, using rule: (T) -> T) -> T {
    return rule(input)
}


/* number = modify(number, using: doubled)*/


number = modify(number){input in input * 2}
doubleNumber = modify(doubleNumber){input in input * 2.0}
string = modify(string){input in input + " " + input}
number
doubleNumber
string

let numberOfCopiesSold = [5, 9, 2, 8, 11, 4, 3]

let moneyEarned = numberOfCopiesSold.map{numberSold in Double(numberSold) * 1.99 * 0.70}
moneyEarned



//: [TOC](TOC) - [Previous](@previous) - [Next](@next)