//: ## Functions
//: [TOC](TOC) - [Previous](@previous) - [Next](@next)

func hello() {
    hello("World")
}


func hello(name: String) {
    print("Hello, \(name)!")
}

func hello(name: String, numberOfTimes: Int) {
    for _ in 1 ... numberOfTimes{
        hello(name)
    }
}

hello()
hello("my friend")
hello("Someone", numberOfTimes: 7)

func hi(name: String = "World") {
    hello(name)
}

hi()
hi("my default buddy")

func hey(name: String = "World", numberOfTimes: Int = 1) {
    for _ in 1 ... numberOfTimes {
        hello(name)
    }
}

hey()
hey("non-default")
hey(numberOfTimes: 4)
hey("another non-default", numberOfTimes: 3)

func hello(to name:String, _ numberOfTimes: Int) {
    for _ in 1 ... numberOfTimes {
        hello(name)
    }
}

hello(to: "Anabelle", 3)

func welcome(people: String...) {
    for person in people {
        hello(person)
    }
}

welcome()
welcome("Joan", "John")

func whatsUp(name: String) -> String {
    return "Hello, \(name)!"
}

whatsUp("There")

func helloFriends(people: String...) -> (numberOfFriends: Int, greeting: String) {
    var tempGreeting = "Hello, "
    for person in people {
        tempGreeting += person + "\n"
    }
    return (people.count, tempGreeting)
}

let result = helloFriends("Chris", "Josh", "James")
result.0
result.1

result.numberOfFriends
result.greeting

let (numberOfPeople, finalGreeting) = helloFriends("Chris", "Josh", "James")
numberOfPeople
finalGreeting

//: [TOC](TOC) - [Previous](@previous) - [Next](@next)
