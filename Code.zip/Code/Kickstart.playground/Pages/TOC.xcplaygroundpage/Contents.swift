/*:
 ##  Swift Kickstart
 ### Part 1: Fundamentals
 * [Functions](1%20Functions)
 * [Variables and Constants](2%20Variables%20and%20Constants)
 * [Collections](3%20Collections)
 * [More Functions](4%20More%20Functions)
 ### Part 2: Types
 * [Classes](5%20Classes)
 * [Enumerations](6%20Enumerations)
 * [Classes and Enumerations](7%20Classes%20and%20Enumerations)
 * [Structs](8%20Structs)
 * [Protocols](9%20Protocols)
 */
