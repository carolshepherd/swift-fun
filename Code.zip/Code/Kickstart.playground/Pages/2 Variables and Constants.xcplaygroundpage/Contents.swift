//: ## Variables and Constants
//: [TOC](TOC) - [Previous](@previous) - [Next](@next)


/*let literalCalculation = 5 * 6.0

let someInt = 6

let someDouble = 5.0

// let productAsDouble = someInt * someDouble

let someIntAsDouble = Double(someInt)

let productAsDouble = someIntAsDouble * someDouble */

let person = "Class Attendee"

func columbusWelcome(for name: String) -> String {
    let greeting = "\(name), welcome to Columbus."
    return greeting
}
func bostonWelcome(for name: String) -> String {
    let greeting = "\(name), welcome to Boston."
    return greeting
}

let greeting1 = columbusWelcome(for: person)
let greeting2 = bostonWelcome(for: person)

func columbusWelcome() -> String {
    return "Welcome to Columbus"
}

let personalColumbusWelcome = columbusWelcome(for:)
let generalColumbusWelcome: () -> String = columbusWelcome

let greeting3 = personalColumbusWelcome(for: person)

func traditionalWelcome(forPersonNamed name: String,
                        toCityNamed location: String)
    -> String {
        let greeting = "\(name), welcome to \(location)."
        return greeting
}

let greeting4 = traditionalWelcome(forPersonNamed: "Joe", toCityNamed: "Amsterdam")

func welcome(to location: String) -> (forPersonNamed: String) -> String {
    func locationWelcome(name: String) -> String {
        let greeting = "\(name), welcome to \(location)."
        return greeting
    }
    return locationWelcome
}

let cbusWelcome = welcome(to: "Columbus")
let greeting5 = cbusWelcome(forPersonNamed: person)

let greeting6 = welcome(to: "Boston")(forPersonNamed: person)


func greet(_ name: String,
             withMessage message:(String) -> String) -> String {
    return message(name)
}

let greeting7 = greet(person, withMessage: cbusWelcome)



//: [TOC](TOC) - [Previous](@previous) - [Next](@next)
