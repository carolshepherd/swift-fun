public protocol Movable {
    func moved(byX deltaX: Int) -> Self
    func shiftedRight() -> Self
}

public func shiftedLeft<T: Movable>(_ movable: T) -> T {
    return movable.moved(byX: -1)
}

public extension Movable {
    public func shiftedRight() -> Self {
        return moved(byX: 1)
    }
}
