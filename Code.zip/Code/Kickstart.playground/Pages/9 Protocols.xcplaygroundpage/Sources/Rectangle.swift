public struct Rectangle {
    let topLeftCorner: Vertex
    let size: Size
    
    public init(topLeftCorner: Vertex, width: Int, height: Int) {
        self.topLeftCorner = topLeftCorner
        size = Size(width: width, height: height)
    }
}

extension Rectangle: Movable {
    public func moved(byX deltaX: Int) -> Rectangle {
        let movedTopLeftCorner = topLeftCorner.moved(byX: deltaX)
        return Rectangle(topLeftCorner: movedTopLeftCorner, width: size.width, height: size.height)
    }
    public func shiftedRight() -> Rectangle {
        return Rectangle(topLeftCorner: Vertex(x: 0,y: 0), width: 10, height: 10)
    }
}

extension Rectangle: CustomStringConvertible {
    public var description: String {
        return "\(size) with top left corner: \(topLeftCorner)."
    }
}

extension Rectangle: Equatable{}

public func ==(lhs: Rectangle, rhs: Rectangle) -> Bool {
    return lhs.topLeftCorner == rhs.topLeftCorner && lhs.size == rhs.size
}
