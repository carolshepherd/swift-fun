//: ## Protocols
//: [TOC](TOC) - [Previous](@previous) - [Next](@next)
let vertex = Vertex(x: 3, y: 4)
let movedRightBy10Vertex = vertex.moved(byX: 10)

vertex == movedRightBy10Vertex
vertex != movedRightBy10Vertex

let rectangle = Rectangle(topLeftCorner: vertex, width: 100, height: 50)
let movedLeftBy7Rectangle = rectangle.moved(byX: -7)

let shiftedLeftVertex = shiftedLeft(vertex)
let shiftedLeftRectangle = shiftedLeft(rectangle)

let returnedVertex = shiftedLeftVertex.shiftedRight()
let returnedRectangle = shiftedLeftRectangle.shiftedRight()

returnedVertex == vertex
returnedRectangle == rectangle

let movableRectangle: Movable = rectangle

let shiftRightRectangle = rectangle.shiftedRight()
let shiftRightMovableRectangle = movableRectangle.shiftedRight()

//: [TOC](TOC) - [Previous](@previous) - [Next](@next)
