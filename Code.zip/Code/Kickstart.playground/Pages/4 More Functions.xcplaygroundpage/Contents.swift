//: ## More Functions
//: [TOC](TOC) - [Previous](@previous) - [Next](@next)

let constant = 6
var variable = 6

func double(_ input: inout Int) {
    input = input * 2
}

func doubled(_ input: Int) -> Int {
    return input * 2
}

//double(&constant)
double(&variable)


let doubledConstant = doubled(constant)
constant
let doubledVariable = doubled(variable)



extension Int {
    mutating func double() {
        self = self * 2
    }
    
    func doubled() -> Int {
        return self * 2
    }
}

variable.double()
variable

variable.doubled()
variable

var number = 6
let doubleNumber = 6.0
let myString = "six"


func modify<T>(input: T, using rule: (T) -> T) -> T {
    return rule(input)
}

modify(input: number, using: doubled)
number

let doubledInt = modify(input: number){myInt in myInt * 2}
doubledInt
number
number = modify(input: number){myInt in myInt * 2}
number

let doubledDouble = modify(input: doubleNumber){myDouble in myDouble * 2.0}
doubledDouble
doubleNumber

let doubledString = modify(input: myString){myString in myString + " times two"}
doubledString
myString


let numberOfCopiesSold = [5, 9, 2, 8, 11, 4, 3]

let moneyEarned = numberOfCopiesSold.map{numberSold in Double(numberSold) * 1.99 * 0.70}
moneyEarned



//: [TOC](TOC) - [Previous](@previous) - [Next](@next)
