//: ## Functions
//: [TOC](TOC) - [Previous](@previous) - [Next](@next)


func greet(_ name: String = "World", using greeting: String = "Hello", numberOfTimes: Int = 1) {
    for _ in 1 ... numberOfTimes {
        print(greeting, ", ", name, "!", separator: "")
    }
}

greet()
greet("my friend")
greet("students", using: "Hi")
greet(using: "Bonjour")
greet("beautiful day", using: "Hi there", numberOfTimes: 3)

func hello(_ names: String...) {
    for name in names {
        greet(name)
    }
}

hello("Ann", "Bob", "Cathy", "Dave")


func whatsUp(_ name: String) -> String {
    return "Hello, \(name)!"
}

whatsUp("There")


func wakeUp(_ people: String...) -> (numberOfFriends: Int, greeting: String) {
    var tempGreeting = "Wake up: \n"
    for person in people {
        tempGreeting += "\t" + person + "\n "
    }
    return (people.count, tempGreeting)
}

let result = wakeUp("Chris", "Josh", "James")
result.0
result.1

result.numberOfFriends
result.greeting

let (numberOfPeople, finalGreeting) = wakeUp("Chris", "Josh", "James")
numberOfPeople
finalGreeting
print(finalGreeting)

//: [TOC](TOC) - [Previous](@previous) - [Next](@next)
