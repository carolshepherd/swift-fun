//: ## Structs
//: [TOC](TOC) - [Previous](@previous) - [Next](@next)
struct Attendee {
    private(set) var name: String
    let hometown: String?
    
    mutating func changeName(to name: String) {
        self.name = name
    }
    
    func relocated(to hometown: String?) -> Attendee {
        return Attendee(name: self.name, hometown: hometown)
    }
    
    func nameBadge() -> String {
        let greeting = "Hello, I'm \(name)"
        guard let location = hometown else { return greeting + "." }
        return greeting + " from \(location)."
    }
}

var daniel = Attendee(name: "Daniel", hometown: "Shaker Heights")
daniel.nameBadge()


struct Student {
    private var attendee: Attendee
    let tutorial: String
    var name: String {
        get {
            return attendee.name
        }
        set {
            attendee.changeName(to: newValue)
        }
    }
    var hometown: String? {
        get {
            return attendee.hometown
        }
        set {
            attendee = attendee.relocated(to: newValue)
        }
    }
    
    init(name: String, tutorial: String, hometown: String? = nil) {
        attendee = Attendee(name: name, hometown: hometown)
        self.tutorial = tutorial
    }
    
    func nameBadge() -> String {
        return attendee.nameBadge() + "I'm taking \(tutorial)."
    }
}

var kimberli = Student(name: "Kimberli", tutorial: "Swift")
kimberli.name
kimberli.hometown
kimberli.hometown = "Boston"
kimberli.hometown
kimberli.nameBadge()



//: [TOC](TOC) - [Previous](@previous) - [Next](@next)
