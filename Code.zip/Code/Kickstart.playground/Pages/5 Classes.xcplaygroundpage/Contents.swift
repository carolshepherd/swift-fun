//: ## Classes
//: [TOC](TOC) - [Previous](@previous) - [Next](@next)

class Attendee {
    let name: String
    let hometown: String?
    
    init(name: String, hometown: String? = nil) {
        self.name = name
        self.hometown = hometown
    }
    func nameBadge() -> String {
        let greeting = "Hello, I'm \(name)"
        guard let location = hometown else { return greeting + "." }
        return greeting + " from \(location)."
    }
}



class Student: Attendee {
    let tutorial: String
    
    init(name: String, tutorial: String, hometown: String? = nil) {
        self.tutorial = tutorial
        super.init(name: name, hometown: hometown)
    }
    override func nameBadge() -> String {
        return super.nameBadge() + " I'm taking \(tutorial)."
    }
}

let daniel = Attendee(name: "Daniel", hometown: "Shaker Heights")
daniel.nameBadge()

let kimberli = Student(name: "Kimberli", tutorial: "Swift")
kimberli.nameBadge()
//
////: [TOC](TOC) - [Previous](@previous) - [Next](@next)
