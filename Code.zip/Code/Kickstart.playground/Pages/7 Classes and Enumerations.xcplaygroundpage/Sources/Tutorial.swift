public enum Tutorial: String {
    case lldb = "Debugging in Swift"
    case iOS10
    case swift = "A Swift Kickstart"
    case coredata
    
   public var name: String {
        return rawValue
    }
}
