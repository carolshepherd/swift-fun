public enum Registration {
    case regular
    case full(Tutorial)
    
    public var tutorial: Tutorial? {
        switch self {
        case .full(let course):
            return course
        default:
            return nil
        }
    }
}