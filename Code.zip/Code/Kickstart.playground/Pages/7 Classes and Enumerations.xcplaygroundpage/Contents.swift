//: ## Classes and Enumerations
//: [TOC](TOC) - [Previous](@previous) - [Next](@next)


class Attendee {
    let name: String
    let hometown: String?
    private(set) var registration = Registration.regular
    
    init(name: String, hometown: String? = nil) {
        self.name = name
        self.hometown = hometown
    }
    func nameBadge() -> String {
        let greeting = "Hello, I'm \(name)"
        guard let location = hometown else { return greeting + "." }
        return greeting + " from \(location)."
    }
}



class Student: Attendee {
    
    init(name: String, tutorial: Tutorial, hometown: String? = nil) {
        super.init(name: name, hometown: hometown)
        registration = .full(tutorial)
    }
    override func nameBadge() -> String {
        guard let tutorialName = registration.tutorial?.name else {
            fatalError("A Student must have a Tutorial with a name.")
        }
        return super.nameBadge() + " I'm taking \(tutorialName)."
    }
}

let daniel = Attendee(name: "Daniel", hometown: "Shaker Heights")
daniel.nameBadge()

let kimberli = Student(name: "Kimberli", tutorial: .swift)
kimberli.nameBadge()

//: [TOC](TOC) - [Previous](@previous) - [Next](@next)
