//: ## Collections
//: [TOC](TOC) - [Previous](@previous) - [Next](@next)

let numbers = [0,1,2]
let one = numbers[1]
let two = numbers[2]

let three = one + two

import Foundation

let badNumbers = [0, 1, 2, "Iguana"]

let badOne = (badNumbers[1] as! NSNumber).intValue
let badTwo = (badNumbers[2] as! NSNumber).intValue

let badThree = badOne + badTwo


var evens = [0,2,4]
evens.append(6)
evens[1] = 8
evens.insert(10, at: 2)
evens[1...2] = [12,14,16]
evens += [100]
evens[0...0] = [200, 202, 204]

evens

//evens.removeLast()
//evens.remove(at: 2)
//evens.removeSubrange(1...4)
//evens.removeAll(keepingCapacity: true)

let sortedEvens = evens.sorted()
sortedEvens
evens

evens.sort()

evens


for i in 0 ..< evens.count {
    print("element", i, "is", evens[i])
}

for even in evens {
    print(even, "has index", evens.index(of: even)!)
}

evens.forEach{ print($0, "also has index", evens.index(of: $0)!) }

for (index, even) in evens.enumerated() {
    print("element", index, "is", even)
}

var digits = ["one": 1, "two": 2, "three": 3]

digits["two"]
digits["four"] = 5
digits["five"] = 5
digits.removeValue(forKey: "five")
digits.removeValue(forKey: "not here")
digits["four"] = 4

digits

let keys = digits.keys

for key in keys {
    print("\(digits[key])")
}

if digits["two"] != nil {
    let digit = digits["two"]!
    print(digit)
} else {
    print("no entry matches key")
}


if let digit = digits["two"] {
    print(digit)
} else {
    print("no entry matches key")
}



var evenSet = Set(evens)
var primeSet: Set = [2, 3, 5, 7, 9]
evenSet.remove(200)

for i in stride(from: 0, through: 10, by: 2) {
    evenSet.insert(i)
}

let intersection = evenSet.intersection(primeSet)
let union = evenSet.union(primeSet)
let difference = evenSet.subtracting(primeSet)
let symmetricDifference = evenSet.symmetricDifference(primeSet)
intersection.isDisjoint(with: symmetricDifference)
intersection.isSubset(of: union)

evenSet.formUnion(primeSet)
evenSet





//: [TOC](TOC) - [Previous](@previous) - [Next](@next)
