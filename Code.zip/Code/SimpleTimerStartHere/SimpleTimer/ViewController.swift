import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak private var timerDisplay: UILabel!
    @IBOutlet private var startStopButtons: [UIButton]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateDisplay()
    }
    
    @IBAction private func start(_ sender: UIButton) {
        toggleButtons()
    }
    @IBAction private func stop(_ sender: UIButton) {
        toggleButtons()
    }
    @IBAction private func reset(_ sender: UIButton) {
    }
    
    private func updateDisplay(_ text: String = "0.00") {
        timerDisplay.text = text
    }
    private func toggleButtons() {
        for button in startStopButtons {
            button.isEnabled = !button.isEnabled
        }
    }
}

