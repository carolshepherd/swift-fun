import Foundation

struct Time {
    private let date: Date
    
    var elapsedTime: Double {
        return date.timeIntervalUntilNow
    }
    
    private init(date: Date) {
        self.date = date
    }
    
    init() {
        self.init(date: Date())
    }
    
    func timeAferPausing(for timeInterval: TimeInterval) -> Time {
        return Time(date: date.addingTimeInterval(timeInterval))
    }
}

extension Date {
    private var timeIntervalUntilNow: TimeInterval {
        return -timeIntervalSinceNow
    }
}
