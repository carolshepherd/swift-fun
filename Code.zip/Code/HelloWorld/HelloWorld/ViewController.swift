//
//  ViewController.swift
//  HelloWorld
//
//  Created by Daniel Steinberg on 7/21/16.
//  Copyright © 2016 Dim Sum Thinking. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textDisplay: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        textDisplay.text = "..."
    }

    @IBAction func helloButton(_ sender: UIButton) {
        textDisplay.text = "Hello, World!"
        sender.isEnabled = false
    }

}

