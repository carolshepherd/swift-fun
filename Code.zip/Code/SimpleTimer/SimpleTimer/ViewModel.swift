import Foundation

class ViewModel {
    
    private var timer: Timer?
    private var time = Time()
    
    private var displayTime: String {
        return time.elapsedTime.formatForDisplay()
    }
    func reset() {
        time = Time()
    }
    
    func start(using f:(String) -> Void) {
        if timer == nil {
            timer = Timer.scheduledTimer(withTimeInterval: 0.03, repeats: true){ _ in
                f(self.displayTime)
                }
        }
    }
    func stop() {
        timer?.invalidate()
        timer = nil
    }
}
