import Foundation

let displayFormatter = Formatter()

struct Formatter {
    private let timeFormatter = NumberFormatter()
    
    private init() {
        timeFormatter.alwaysShowsDecimalSeparator = true
        timeFormatter.minimumIntegerDigits = 1
        timeFormatter.minimumFractionDigits = 2
        timeFormatter.maximumFractionDigits = 2
    }
    
    private func format(_ number: TimeInterval) -> String {
        let timeIntervalAsNumber = NSNumber(value: number)
        return timeFormatter.string(from: timeIntervalAsNumber) ?? "0.00"
    }
}

extension Double {
    func formatForDisplay() -> String {
        return displayFormatter.format(self)
    }
}
