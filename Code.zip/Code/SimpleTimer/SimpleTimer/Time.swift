import Foundation

struct Time {
    private let date = Date()
    
    var elapsedTime: Double {
        return date.timeIntervalUntilNow
    }
}

extension Date {
    private var timeIntervalUntilNow: TimeInterval {
        return -timeIntervalSinceNow
    }
}
