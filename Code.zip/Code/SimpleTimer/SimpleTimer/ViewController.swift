import UIKit

class ViewController: UIViewController {

    private lazy var vm = ViewModel()

    @IBOutlet weak private var timerDisplay: UILabel!
    @IBOutlet private var startStopButtons: [UIButton]!
    @IBOutlet weak var resetButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateDisplay()
    }

    @IBAction private func start(_ sender: UIButton) {
        toggleButtons()
        vm.start(using: updateDisplay)
    }
    @IBAction private func stop(_ sender: UIButton) {
        toggleButtons()
        vm.stop()
    }
    @IBAction private func reset(_ sender: UIButton) {
        vm.reset()
        updateDisplay()
    }
    
    private func updateDisplay(_ text: String = "0.00") {
        timerDisplay.text = text
    }
    private func toggleButtons() {
        for button in startStopButtons {
            button.isEnabled = !button.isEnabled
        }
        resetButton.isEnabled = true
    }
}

